/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acces.modifier;

/**
 *
 * @author LAB-RPL
 */
public class DefaultModifier {
    int a = 1;
    int b = 2;
    int c;
    void jumlah(){
    c=a+b;
    System.out.println(c);
   }
public static void main(String[]args){
    DefaultModifier dm = new DefaultModifier();
    
    dm.jumlah();
}
}
