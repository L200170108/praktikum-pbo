/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acces.modifier;

/**
 *
 * @author LAB-RPL
 */
public class PrivateModifier {
    private String nama;
    private int umur;
    private void printInfo(){
        System.out.println("Private Modifier");
    }
    
public static void main(String[]args){
    PrivateModifier priv = new PrivateModifier();
    
    priv.printInfo();
}
}
