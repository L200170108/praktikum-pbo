/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.pbo.package1;

import acces.modifier.PrivateModifier;
import acces.modifier.ProtectedModifier;
import acces.modifier.PublicModifier;



/**
 *
 * @author LAB-RPL
 */
public class Latihan1 {
    public static void main(String[]args){
        System.out.println("Default Modifier");
        //jumlah1.jumlah();
        System.out.println("Default Modifier tidak bisa diakses");
        
        System.out.println("Public Modifier");
        PublicModifier pm = new PublicModifier();
        pm.kali();
        pm.tambah();
        pm.kurang();
        pm.bagi();
        pm.nilairata();
        
        System.out.println("Protected Modifier");
        ProtectedModifier modif = new ProtectedModifier();
        //modif.printInfo();
        System.out.println("Protected Modifier tidak bisa di akses");
        
        System.out.println("Private Modifier");
        PrivateModifier priv = new PrivateModifier();
        
        //priv.printInfo();
        System.out.println("Private Modifier tidak bisa di akses");
}
}
